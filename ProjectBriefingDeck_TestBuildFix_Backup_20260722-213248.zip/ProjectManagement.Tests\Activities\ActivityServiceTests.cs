using System;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ClosedXML.Excel;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging.Abstractions;
using ProjectManagement.Application.Security;
using ProjectManagement.Contracts.Activities;
using ProjectManagement.Features.MediaLibrary.Services;
using ProjectManagement.Data;
using ProjectManagement.Infrastructure.Activities;
using ProjectManagement.Models.Activities;
using ProjectManagement.Services;
using ProjectManagement.Services.Activities;
using ProjectManagement.Services.DocRepo;
using ProjectManagement.Services.Storage;
using Xunit;

namespace ProjectManagement.Tests.Activities;

public class ActivityInputValidatorTests : IDisposable
{
    private readonly ApplicationDbContext _context;
    private readonly IActivityRepository _activityRepository;
    private readonly IActivityTypeRepository _activityTypeRepository;
    private readonly ActivityInputValidator _validator;

    public ActivityInputValidatorTests()
    {
        _context = ActivityTestHelpers.CreateContext();
        _activityRepository = new ActivityRepository(_context);
        _activityTypeRepository = new ActivityTypeRepository(_context);
        _validator = new ActivityInputValidator(_activityRepository, _activityTypeRepository);
    }

    [Fact]
    public async Task ValidateAsync_ThrowsWhenTitleMissing()
    {
        var input = new ActivityInput(string.Empty, null, null, 0, null, null);
        await Assert.ThrowsAsync<ActivityValidationException>(() => _validator.ValidateAsync(input, null, CancellationToken.None));
    }

    [Fact]
    public async Task ValidateAsync_ThrowsWhenTypeInactive()
    {
        var type = new ActivityType
        {
            Name = "Briefings",
            CreatedByUserId = "user",
            IsActive = false
        };
        _context.ActivityTypes.Add(type);
        await _context.SaveChangesAsync();

        var input = new ActivityInput("Kickoff", null, null, type.Id, null, null);
        var ex = await Assert.ThrowsAsync<ActivityValidationException>(() => _validator.ValidateAsync(input, null, CancellationToken.None));
        Assert.Contains(nameof(input.ActivityTypeId), ex.Errors.Keys);
    }

    [Fact]
    public async Task ValidateAsync_ThrowsWhenDuplicateTitle()
    {
        var type = new ActivityType
        {
            Name = "Training",
            CreatedByUserId = "user",
            IsActive = true
        };
        _context.ActivityTypes.Add(type);
        await _context.SaveChangesAsync();

        var activity = new Activity
        {
            Title = "Safety Brief",
            ActivityTypeId = type.Id,
            CreatedByUserId = "owner"
        };
        await _activityRepository.AddAsync(activity);

        var input = new ActivityInput("Safety Brief", null, null, type.Id, null, null);
        var ex = await Assert.ThrowsAsync<ActivityValidationException>(() => _validator.ValidateAsync(input, null, CancellationToken.None));
        Assert.Contains(nameof(input.Title), ex.Errors.Keys);
    }

    [Theory]
    [InlineData("safety brief")]
    [InlineData("SAFETY BRIEF")]
    public async Task ValidateAsync_ThrowsWhenCreateTitleDiffersOnlyByCase(string duplicateTitle)
    {
        // SECTION: Arrange an existing activity for create duplicate validation
        var type = new ActivityType
        {
            Name = "Create Case Check",
            CreatedByUserId = "user",
            IsActive = true
        };
        _context.ActivityTypes.Add(type);
        await _context.SaveChangesAsync();

        await _activityRepository.AddAsync(new Activity
        {
            Title = "Safety Brief",
            ActivityTypeId = type.Id,
            CreatedByUserId = "owner"
        });

        // SECTION: Act and assert
        var input = new ActivityInput(duplicateTitle, null, null, type.Id, null, null);
        var ex = await Assert.ThrowsAsync<ActivityValidationException>(() => _validator.ValidateAsync(input, null, CancellationToken.None));
        Assert.Contains(nameof(input.Title), ex.Errors.Keys);
    }

    [Fact]
    public async Task ValidateAsync_ThrowsWhenEditTitleDiffersOnlyByCaseFromAnotherActivity()
    {
        // SECTION: Arrange two activities in the same type for edit duplicate validation
        var type = new ActivityType
        {
            Name = "Edit Case Check",
            CreatedByUserId = "user",
            IsActive = true
        };
        _context.ActivityTypes.Add(type);
        await _context.SaveChangesAsync();

        var existingActivity = new Activity
        {
            Title = "Existing Brief",
            ActivityTypeId = type.Id,
            CreatedByUserId = "owner"
        };
        var editedActivity = new Activity
        {
            Title = "Editable Brief",
            ActivityTypeId = type.Id,
            CreatedByUserId = "owner"
        };

        await _activityRepository.AddAsync(existingActivity);
        await _activityRepository.AddAsync(editedActivity);

        // SECTION: Act and assert
        var input = new ActivityInput("existing brief", null, null, type.Id, null, null);
        var ex = await Assert.ThrowsAsync<ActivityValidationException>(() => _validator.ValidateAsync(input, editedActivity, CancellationToken.None));
        Assert.Contains(nameof(input.Title), ex.Errors.Keys);
    }

    [Fact]
    public async Task ValidateAsync_AllowsEditWhenTitleDiffersOnlyByCaseFromSameActivity()
    {
        // SECTION: Arrange an existing activity being edited
        var type = new ActivityType
        {
            Name = "Self Edit Case Check",
            CreatedByUserId = "user",
            IsActive = true
        };
        _context.ActivityTypes.Add(type);
        await _context.SaveChangesAsync();

        var editedActivity = new Activity
        {
            Title = "Editable Brief",
            ActivityTypeId = type.Id,
            CreatedByUserId = "owner"
        };
        await _activityRepository.AddAsync(editedActivity);

        // SECTION: Act and assert
        var input = new ActivityInput("editable brief", null, null, type.Id, null, null);
        await _validator.ValidateAsync(input, editedActivity, CancellationToken.None);
    }

    public void Dispose()
    {
        _context.Dispose();
    }
}

public class ActivityTypeValidatorTests : IDisposable
{
    private readonly ApplicationDbContext _context;
    private readonly ActivityTypeValidator _validator;
    private readonly IActivityTypeRepository _activityTypeRepository;

    public ActivityTypeValidatorTests()
    {
        _context = ActivityTestHelpers.CreateContext();
        _activityTypeRepository = new ActivityTypeRepository(_context);
        _validator = new ActivityTypeValidator(_activityTypeRepository);
    }

    [Fact]
    public async Task ValidateAsync_ThrowsWhenNameDuplicate()
    {
        _context.ActivityTypes.Add(new ActivityType
        {
            Name = "Engagement",
            CreatedByUserId = "user"
        });
        await _context.SaveChangesAsync();

        var input = new ActivityTypeInput("Engagement", null, true);
        var ex = await Assert.ThrowsAsync<ActivityValidationException>(() => _validator.ValidateAsync(input, null, CancellationToken.None));
        Assert.Contains(nameof(input.Name), ex.Errors.Keys);
    }

    public void Dispose()
    {
        _context.Dispose();
    }
}

public class ActivityAttachmentValidatorTests
{
    private readonly ActivityAttachmentValidator _validator = new();

    [Fact]
    public void Validate_ThrowsForUnsupportedContentType()
    {
        var upload = new ActivityAttachmentUpload(new MemoryStream(new byte[] { 1 }), "file.exe", "application/octet-stream", 1);
        var ex = Assert.Throws<ActivityValidationException>(() => _validator.Validate(upload));
        Assert.Contains(nameof(upload.ContentType), ex.Errors.Keys);
    }

    [Theory]
    [InlineData("document.pdf", "application/pdf")]
    [InlineData("image.PNG", "image/png")]
    [InlineData("photo.jpeg", "image/jpeg")]
    [InlineData("clip.mp4", "video/mp4")]
    [InlineData("recording.MOV", "video/quicktime")]
    [InlineData("screen.webm", "video/webm")]
    public void Validate_AllowsWhitelistedTypesAndExtensions(string fileName, string contentType)
    {
        var upload = new ActivityAttachmentUpload(new MemoryStream(new byte[] { 1 }), fileName, contentType, 1);
        _validator.Validate(upload);
    }

    [Theory]
    [InlineData("notes.docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")]
    [InlineData("sheet.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")]
    [InlineData("slides.pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation")]
    public void Validate_AllowsOfficeDocumentTypes(string fileName, string contentType)
    {
        var upload = new ActivityAttachmentUpload(new MemoryStream(new byte[] { 1 }), fileName, contentType, 1);

        _validator.Validate(upload);
    }

    [Theory]
    [InlineData("notes.docx", "application/octet-stream")]
    [InlineData("sheet.xlsx", "application/octet-stream")]
    [InlineData("slides.pptx", "application/octet-stream")]
    [InlineData("legacy.doc", "")]
    [InlineData("legacy.xls", "")]
    [InlineData("legacy.ppt", "")]
    public void Validate_AllowsOfficeDocumentsWhenBrowserReportsUnknownContentType(string fileName, string contentType)
    {
        var upload = new ActivityAttachmentUpload(new MemoryStream(new byte[] { 1 }), fileName, contentType, 1);

        _validator.Validate(upload);
    }

    [Fact]
    public void Validate_ThrowsWhenExtensionDoesNotMatchContentType()
    {
        var upload = new ActivityAttachmentUpload(new MemoryStream(new byte[] { 1 }), "clip.mov", "video/mp4", 1);
        var ex = Assert.Throws<ActivityValidationException>(() => _validator.Validate(upload));

        Assert.Contains(nameof(upload.FileName), ex.Errors.Keys);
        Assert.Contains("extension", ex.Errors[nameof(upload.FileName)].Single());
    }

    [Fact]
    public void Validate_ThrowsWhenExtensionMissing()
    {
        var upload = new ActivityAttachmentUpload(new MemoryStream(new byte[] { 1 }), "clip", "video/mp4", 1);
        var ex = Assert.Throws<ActivityValidationException>(() => _validator.Validate(upload));

        Assert.Contains(nameof(upload.FileName), ex.Errors.Keys);
        Assert.Contains("include an extension", ex.Errors[nameof(upload.FileName)].Single());
    }
}

public class ActivityServiceTests : IDisposable
{
    private readonly ApplicationDbContext _context;
    private readonly ActivityRepository _activityRepository;
    private readonly ActivityTypeRepository _activityTypeRepository;
    private readonly ActivityInputValidator _inputValidator;
    private readonly ActivityTypeValidator _typeValidator;
    private readonly ActivityAttachmentValidator _attachmentValidator;
    private readonly ActivityAttachmentManager _attachmentManager;
    private readonly TestUserContext _userContext;
    private readonly TestClock _clock = new();
    private readonly TestUploadRootProvider _uploadRoot;
    private readonly IPrismMediaIngestionCoordinator _mediaIngestion = new StubPrismMediaIngestionCoordinator();
    private readonly ActivityService _service;

    public ActivityServiceTests()
    {
        _context = ActivityTestHelpers.CreateContext();
        _activityRepository = new ActivityRepository(_context);
        _activityTypeRepository = new ActivityTypeRepository(_context);
        _inputValidator = new ActivityInputValidator(_activityRepository, _activityTypeRepository);
        _typeValidator = new ActivityTypeValidator(_activityTypeRepository);
        _attachmentValidator = new ActivityAttachmentValidator();
        _userContext = new TestUserContext("owner");
        _uploadRoot = new TestUploadRootProvider();
        var storage = new FileSystemActivityAttachmentStorage(
            _uploadRoot,
            new FileSecurityValidator(),
            NullLogger<FileSystemActivityAttachmentStorage>.Instance);
        var ingestion = new StubDocRepoIngestionService();
        var urlBuilder = new FakeFileUrlBuilder();
        _attachmentManager = new ActivityAttachmentManager(
            _activityRepository,
            storage,
            _attachmentValidator,
            _clock,
            ingestion,
            _uploadRoot,
            urlBuilder,
            NullLogger<ActivityAttachmentManager>.Instance);
        _service = new ActivityService(_activityRepository,
            _inputValidator,
            _attachmentManager,
            _userContext,
            _clock,
            _mediaIngestion,
            NullLogger<ActivityService>.Instance);
    }

    [Fact]
    public async Task CreateAsync_PersistsActivity()
    {
        var type = await EnsureActivityTypeAsync();

        var input = new ActivityInput("Project Kickoff", "Initial meeting", "HQ", type.Id, _clock.UtcNow, _clock.UtcNow.AddHours(2));
        var activity = await _service.CreateAsync(input);

        Assert.Equal("Project Kickoff", activity.Title);
        Assert.Equal("owner", activity.CreatedByUserId);
        Assert.NotEqual(default, activity.Id);
    }

    [Fact]
    public async Task UpdateAsync_ThrowsForUnauthorizedUser()
    {
        var type = await EnsureActivityTypeAsync();
        var created = await _service.CreateAsync(new ActivityInput("Workshop", null, null, type.Id, null, null));

        var otherUser = new TestUserContext("other");
        var otherService = new ActivityService(_activityRepository,
            _inputValidator,
            _attachmentManager,
            otherUser,
            _clock,
            _mediaIngestion,
            NullLogger<ActivityService>.Instance);

        await Assert.ThrowsAsync<ActivityAuthorizationException>(() => otherService.UpdateAsync(created.Id, new ActivityInput("Workshop", null, null, type.Id, null, null)));
    }

    [Fact]
    public async Task UpdateAsync_AllowsHoDOverride()
    {
        var type = await EnsureActivityTypeAsync();
        var created = await _service.CreateAsync(new ActivityInput("Seminar", null, null, type.Id, null, null));

        var hodContext = new TestUserContext("hod-user", isHoD: true);
        var hodService = new ActivityService(_activityRepository,
            _inputValidator,
            _attachmentManager,
            hodContext,
            _clock,
            _mediaIngestion,
            NullLogger<ActivityService>.Instance);

        var updated = await hodService.UpdateAsync(created.Id, new ActivityInput("Seminar Updated", null, null, type.Id, null, null));
        Assert.Equal("Seminar Updated", updated.Title);
    }

    [Fact]
    public async Task UpdateAsync_AllowsProjectOfficeManager()
    {
        var type = await EnsureActivityTypeAsync();
        var created = await _service.CreateAsync(new ActivityInput("Briefing", null, null, type.Id, null, null));

        var projectOfficeContext = new TestUserContext("po-user", isProjectOffice: true);
        var projectOfficeService = new ActivityService(_activityRepository,
            _inputValidator,
            _attachmentManager,
            projectOfficeContext,
            _clock,
            _mediaIngestion,
            NullLogger<ActivityService>.Instance);

        var updated = await projectOfficeService.UpdateAsync(created.Id, new ActivityInput("Briefing Updated", null, null, type.Id, null, null));
        Assert.Equal("Briefing Updated", updated.Title);
    }

    [Fact]
    public async Task DeleteAsync_AllowsAdminUser()
    {
        var type = await EnsureActivityTypeAsync();
        var created = await _service.CreateAsync(new ActivityInput("Review", null, null, type.Id, null, null));

        var adminService = CreateService(new TestUserContext("admin", isAdmin: true));

        await adminService.DeleteAsync(created.Id);

        var stored = await _activityRepository.GetByIdAsync(created.Id);
        Assert.True(stored!.IsDeleted);
        Assert.NotNull(stored.DeletedAtUtc);
    }

    [Fact]
    public async Task DeleteAsync_RemovesStoredAttachments()
    {
        var type = await EnsureActivityTypeAsync();
        var created = await _service.CreateAsync(new ActivityInput("Archive", null, null, type.Id, null, null));

        await using var stream = new MemoryStream(Encoding.UTF8.GetBytes("hello"));
        var upload = new ActivityAttachmentUpload(stream, "notes.pdf", "application/pdf", stream.Length);
        var attachment = await _service.AddAttachmentAsync(created.Id, upload);
        var path = Path.Combine(_uploadRoot.RootPath, attachment.StorageKey.Replace('/', Path.DirectorySeparatorChar));
        Assert.True(File.Exists(path));

        var adminService = CreateService(new TestUserContext("admin", isAdmin: true));

        await adminService.DeleteAsync(created.Id);

        Assert.False(File.Exists(path));
    }

    [Fact]
    public async Task DeleteAsync_RejectsProjectOfficeUser()
    {
        var type = await EnsureActivityTypeAsync();
        var created = await _service.CreateAsync(new ActivityInput("Review", null, null, type.Id, null, null));

        var projectOfficeService = CreateService(new TestUserContext("po-user", isProjectOffice: true));

        await Assert.ThrowsAsync<ActivityAuthorizationException>(() => projectOfficeService.DeleteAsync(created.Id));

        var stored = await _activityRepository.GetByIdAsync(created.Id);
        Assert.False(stored!.IsDeleted);
    }

    [Fact]
    public async Task DeleteAsync_AllowsHoDUser()
    {
        var type = await EnsureActivityTypeAsync();
        var created = await _service.CreateAsync(new ActivityInput("Review", null, null, type.Id, null, null));

        var hodService = CreateService(new TestUserContext("hod-user", isHoD: true));

        await hodService.DeleteAsync(created.Id);

        var stored = await _activityRepository.GetByIdAsync(created.Id);
        Assert.True(stored!.IsDeleted);
    }

    [Fact]
    public async Task AddAttachmentAsync_SavesFile()
    {
        var type = await EnsureActivityTypeAsync();
        var created = await _service.CreateAsync(new ActivityInput("Brief", null, null, type.Id, null, null));

        await using var stream = new MemoryStream(Encoding.UTF8.GetBytes("hello"));
        var upload = new ActivityAttachmentUpload(stream, "notes.pdf", "application/pdf", stream.Length);

        var attachment = await _service.AddAttachmentAsync(created.Id, upload);

        Assert.Equal("notes.pdf", attachment.OriginalFileName);
        var path = Path.Combine(_uploadRoot.RootPath, attachment.StorageKey.Replace('/', Path.DirectorySeparatorChar));
        Assert.True(File.Exists(path));
    }

    [Fact]
    public async Task RemoveAttachmentAsync_AllowsUploader()
    {
        var type = await EnsureActivityTypeAsync();
        var created = await _service.CreateAsync(new ActivityInput("Drill", null, null, type.Id, null, null));

        await using var stream = new MemoryStream(Encoding.UTF8.GetBytes("hello"));
        var upload = new ActivityAttachmentUpload(stream, "notes.pdf", "application/pdf", stream.Length);
        var attachment = await _service.AddAttachmentAsync(created.Id, upload);

        await _service.RemoveAttachmentAsync(attachment.Id);

        var stored = await _activityRepository.GetAttachmentByIdAsync(attachment.Id);
        Assert.Null(stored);
    }

    [Fact]
    public async Task AddAttachmentAsync_EnforcesAttachmentLimit()
    {
        var type = await EnsureActivityTypeAsync();
        var created = await _service.CreateAsync(new ActivityInput("Briefing", null, null, type.Id, null, null));

        for (var i = 0; i < ActivityAttachmentManager.MaxAttachmentsPerActivity; i++)
        {
            await using var stream = new MemoryStream(Encoding.UTF8.GetBytes($"file-{i}"));
            var upload = new ActivityAttachmentUpload(stream, $"file-{i}.pdf", "application/pdf", stream.Length);
            await _service.AddAttachmentAsync(created.Id, upload);
        }

        await using var overflowStream = new MemoryStream(Encoding.UTF8.GetBytes("overflow"));
        var overflowUpload = new ActivityAttachmentUpload(overflowStream, "overflow.pdf", "application/pdf", overflowStream.Length);

        var ex = await Assert.ThrowsAsync<ActivityValidationException>(() => _service.AddAttachmentAsync(created.Id, overflowUpload));
        Assert.Contains(nameof(Activity.Attachments), ex.Errors.Keys);
    }

    [Fact]
    public async Task GetAttachmentMetadataAsync_ReturnsDownloadLink()
    {
        var type = await EnsureActivityTypeAsync();
        var created = await _service.CreateAsync(new ActivityInput("Review", null, null, type.Id, null, null));

        await using var stream = new MemoryStream(Encoding.UTF8.GetBytes("hello"));
        var upload = new ActivityAttachmentUpload(stream, "  diagram?.pdf  ", "application/pdf", stream.Length);
        var attachment = await _service.AddAttachmentAsync(created.Id, upload);

        var metadata = await _service.GetAttachmentMetadataAsync(created.Id);
        var item = Assert.Single(metadata);
        Assert.Equal(ActivityAttachmentValidator.SanitizeFileName(upload.FileName), item.FileName);
        Assert.StartsWith("/files?t=", item.DownloadUrl, StringComparison.Ordinal);
        Assert.False(string.IsNullOrWhiteSpace(item.DownloadUrl));
        Assert.Equal(attachment.Id, item.Id);
    }

    [Fact]
    public async Task ActivityTypeService_RestrictsNonPrivilegedUsers()
    {
        var typeService = new ActivityTypeService(_activityTypeRepository, _typeValidator, _userContext, _clock);
        await Assert.ThrowsAsync<ActivityAuthorizationException>(() => typeService.CreateAsync(new ActivityTypeInput("Operations", null, true)));
    }

    [Fact]
    public async Task ActivityTypeService_AllowsAdmin()
    {
        var adminContext = new TestUserContext("admin", isAdmin: true);
        var typeService = new ActivityTypeService(_activityTypeRepository, _typeValidator, adminContext, _clock);

        var type = await typeService.CreateAsync(new ActivityTypeInput("Logistics", null, true));
        Assert.Equal("Logistics", type.Name);
    }

    [Fact]
    public async Task ActivityExportService_ProducesSpreadsheetWithAttachmentLinks()
    {
        var type = await EnsureActivityTypeAsync();
        var activity = await _service.CreateAsync(new ActivityInput("Planning", null, "HQ", type.Id, _clock.UtcNow, _clock.UtcNow.AddHours(1)));

        await using (var pdfStream = new MemoryStream(Encoding.UTF8.GetBytes("plan")))
        {
            var upload = new ActivityAttachmentUpload(pdfStream, "plan.pdf", "application/pdf", pdfStream.Length);
            await _service.AddAttachmentAsync(activity.Id, upload);
        }

        await using (var photoStream = new MemoryStream(Encoding.UTF8.GetBytes("photo")))
        {
            var upload = new ActivityAttachmentUpload(photoStream, "photo.jpg", "image/jpeg", photoStream.Length);
            await _service.AddAttachmentAsync(activity.Id, upload);
        }

        var exportService = new ActivityExportService(_activityRepository, _attachmentManager);
        var export = await exportService.ExportAsync(new ActivityExportRequest(ActivityTypeId: type.Id));

        Assert.NotNull(export);
        Assert.StartsWith("MiscActivities_", export!.FileName, StringComparison.Ordinal);
        Assert.EndsWith(".xlsx", export.FileName, StringComparison.OrdinalIgnoreCase);
        Assert.Equal(ActivityExportService.ExcelContentType, export.ContentType);

        using var stream = new MemoryStream(export.Content);
        using var workbook = new XLWorkbook(stream);
        var worksheet = workbook.Worksheet("Activities");

        Assert.Equal("Title", worksheet.Cell(1, 1).GetString());
        Assert.Equal("Attachment links", worksheet.Cell(1, 13).GetString());

        var attachmentsCell = worksheet.Cell(2, 13);
        Assert.Equal(2, worksheet.Cell(2, 12).GetValue<int>());
        Assert.Contains("HYPERLINK", attachmentsCell.FormulaA1, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("plan.pdf", attachmentsCell.FormulaA1, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("photo.jpg", attachmentsCell.FormulaA1, StringComparison.OrdinalIgnoreCase);
    }


    [Fact]
    public async Task ActivityExportService_IgnoresStaleAttachmentTypeAndUsesMediaFilter()
    {
        // SECTION: Arrange an export that should match all media regardless of a stale attachment-type value.
        var type = await EnsureActivityTypeAsync();
        await SeedActivityWithAttachmentAsync(type.Id, "PDF Export Activity", "report.pdf", "application/pdf");
        await SeedActivityWithAttachmentAsync(type.Id, "Photo Export Activity", "photo.jpg", "image/jpeg");

        var exportService = new ActivityExportService(_activityRepository, _attachmentManager);

        // SECTION: Act
        var export = await exportService.ExportAsync(new ActivityExportRequest(
            ActivityTypeId: type.Id,
            AttachmentType: ActivityAttachmentTypeFilter.Photo,
            MediaFilter: ActivityMediaFilter.WithMedia));

        // SECTION: Assert
        Assert.NotNull(export);
        using var stream = new MemoryStream(export!.Content);
        using var workbook = new XLWorkbook(stream);
        var worksheet = workbook.Worksheet("Activities");

        Assert.Equal(2, worksheet.LastRowUsed()!.RowNumber() - 1);
        Assert.Contains("PDF Export Activity", new[] { worksheet.Cell(2, 1).GetString(), worksheet.Cell(3, 1).GetString() });
        Assert.Contains("Photo Export Activity", new[] { worksheet.Cell(2, 1).GetString(), worksheet.Cell(3, 1).GetString() });
    }

    [Fact]
    public async Task ActivityExportService_ReturnsNullWhenNoResults()
    {
        var exportService = new ActivityExportService(_activityRepository, _attachmentManager);
        var export = await exportService.ExportAsync(new ActivityExportRequest(ActivityTypeId: 999));

        Assert.Null(export);
    }

    [Fact]
    public async Task GetReviewSummaryAsync_DoesNotChangeWhenOnlyPageChanges()
    {
        var type = await EnsureActivityTypeAsync();
        await SeedActivityWithAttachmentAsync(type.Id, "Photo Activity", "photo.jpg", "image/jpeg");
        await SeedActivityWithAttachmentAsync(type.Id, "Document Activity", "notes.pdf", "application/pdf");
        await SeedActivityWithAttachmentAsync(type.Id, "Video Activity", "clip.mp4", "video/mp4");
        await SeedActivityWithoutAttachmentAsync(type.Id, "No Media Activity");

        var firstPageRequest = new ActivityListRequest(Page: 1, PageSize: 2, ActivityTypeId: type.Id);
        var secondPageRequest = firstPageRequest with { Page = 2 };

        var firstPageSummary = await _service.GetReviewSummaryAsync(firstPageRequest);
        var secondPageSummary = await _service.GetReviewSummaryAsync(secondPageRequest);

        Assert.Equal(firstPageSummary, secondPageSummary);
        Assert.Equal(new ActivityReviewSummaryResult(All: 4, WithMedia: 3, Photos: 1, Documents: 1, Videos: 1), firstPageSummary);
    }

    [Fact]
    public async Task GetReviewSummaryAsync_IgnoresMediaFilter()
    {
        var type = await EnsureActivityTypeAsync();
        await SeedActivityWithAttachmentAsync(type.Id, "Photo Activity", "photo.jpg", "image/jpeg");
        await SeedActivityWithoutAttachmentAsync(type.Id, "No Media Activity");

        var unfilteredRequest = new ActivityListRequest(Page: 1, PageSize: 10, ActivityTypeId: type.Id);
        var mediaFilteredRequest = unfilteredRequest with { MediaFilter = ActivityMediaFilter.Photos };

        var unfilteredSummary = await _service.GetReviewSummaryAsync(unfilteredRequest);
        var mediaFilteredSummary = await _service.GetReviewSummaryAsync(mediaFilteredRequest);

        Assert.Equal(unfilteredSummary, mediaFilteredSummary);
        Assert.Equal(2, mediaFilteredSummary.All);
    }

    private ActivityService CreateService(TestUserContext userContext)
    {
        return new ActivityService(_activityRepository,
            _inputValidator,
            _attachmentManager,
            userContext,
            _clock,
            _mediaIngestion,
            NullLogger<ActivityService>.Instance);
    }

    private async Task<ActivityType> EnsureActivityTypeAsync()
    {
        var type = new ActivityType
        {
            Name = "Operations",
            IsActive = true,
            CreatedByUserId = "seed"
        };
        await _activityTypeRepository.AddAsync(type);
        return type;
    }

    private async Task SeedActivityWithAttachmentAsync(int activityTypeId, string title, string fileName, string contentType)
    {
        // SECTION: Activity summary test seed
        var activity = await _service.CreateAsync(new ActivityInput(title, null, null, activityTypeId, null, null));
        _context.ActivityAttachments.Add(new ActivityAttachment
        {
            ActivityId = activity.Id,
            OriginalFileName = fileName,
            ContentType = contentType,
            StorageKey = $"activities/{activity.Id}/{fileName}",
            FileSize = 1024,
            UploadedByUserId = "owner"
        });
        await _context.SaveChangesAsync();
    }

    private async Task SeedActivityWithoutAttachmentAsync(int activityTypeId, string title)
    {
        // SECTION: Activity summary test seed
        await _service.CreateAsync(new ActivityInput(title, null, null, activityTypeId, null, null));
    }

    public void Dispose()
    {
        _uploadRoot.Dispose();
        _context.Dispose();
    }
}

internal sealed class TestUserContext : IUserContext
{
    public TestUserContext(string userId, bool isAdmin = false, bool isHoD = false, bool isProjectOffice = false)
    {
        UserId = userId;
        var identity = new ClaimsIdentity();
        identity.AddClaim(new Claim(ClaimTypes.NameIdentifier, userId));
        if (isAdmin)
        {
            identity.AddClaim(new Claim(ClaimTypes.Role, "Admin"));
        }
        if (isHoD)
        {
            identity.AddClaim(new Claim(ClaimTypes.Role, "HoD"));
        }
        if (isProjectOffice)
        {
            identity.AddClaim(new Claim(ClaimTypes.Role, "Project Office"));
        }

        User = new ClaimsPrincipal(identity);
    }

    public ClaimsPrincipal User { get; }

    public string? UserId { get; }
}

internal sealed class TestClock : IClock
{
    public DateTimeOffset UtcNow { get; set; } = DateTimeOffset.UtcNow;
}

// ===== Section: Doc Repo ingestion stub =====
internal sealed class StubDocRepoIngestionService : IDocRepoIngestionService
{
    public Task<Guid> IngestExternalPdfAsync(Stream pdfStream, string originalFileName, string sourceModule, string sourceItemId, CancellationToken cancellationToken = default)
        => Task.FromResult(Guid.NewGuid());
}

internal sealed class FakeFileUrlBuilder : IProtectedFileUrlBuilder
{
    public string CreateDownloadUrl(string storageKey, string? fileName = null, string? contentType = null, TimeSpan? lifetime = null)
        => string.IsNullOrWhiteSpace(storageKey) ? string.Empty : $"/files?t={storageKey}";

    public string CreateInlineUrl(string storageKey, string? fileName = null, string? contentType = null, TimeSpan? lifetime = null)
        => string.IsNullOrWhiteSpace(storageKey) ? string.Empty : $"/files?t={storageKey}&mode=inline";
}

internal sealed class TestUploadRootProvider : IUploadRootProvider, IDisposable
{
    public TestUploadRootProvider()
    {
        RootPath = Path.Combine(Path.GetTempPath(), "pm-test-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(RootPath);
    }

    public string RootPath { get; }

    public string GetProjectRoot(int projectId) => throw new NotSupportedException();

    public string GetProjectPhotosRoot(int projectId) => throw new NotSupportedException();

    public string GetProjectDocumentsRoot(int projectId) => throw new NotSupportedException();

    public string GetProjectCommentsRoot(int projectId) => throw new NotSupportedException();

    public string GetProjectVideosRoot(int projectId) => throw new NotSupportedException();

    public string GetSocialMediaRoot(string storagePrefix, Guid eventId) => throw new NotSupportedException();

    public void Dispose()
    {
        if (Directory.Exists(RootPath))
        {
            Directory.Delete(RootPath, recursive: true);
        }
    }
}

internal static class ActivityTestHelpers
{
    public static ApplicationDbContext CreateContext()
    {
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;
        return new ApplicationDbContext(options);
    }

}

internal sealed class StubPrismMediaIngestionCoordinator : IPrismMediaIngestionCoordinator
{
    public Task<PrismMediaIngestionResult> ReconcileAfterSourceChangeAsync(
        string reason,
        CancellationToken cancellationToken)
        => Task.FromResult(new PrismMediaIngestionResult(true, "Synchronized"));
}
